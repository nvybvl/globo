<section id="header" class="page home">
    <a href="tel://0040724112655"><h1 class="logo">Casa Funerara Iriss</h1></a>
    <div class="row-fluid">
    <div class="span12">
    <div class="middle">
    <div class="iefix">
        <div class="row-fluid logo">
            <div class="vcard span3">
            </div>
            <div class="span6">&nbsp;</div>
            <div class="vcard span3">
                <div class="tel">
                    <a href="tel://0040724112655">NON-STOP</a>
                </div>
            </div>
        </div>
    <div class="row-fluid">
    <div class="span12">
        <!-- -->
            <div id="myCarousel" class="carousel slide" data-ride="carousel">
              <!-- Indicators -->
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                  <img src="img/slider1.jpg" alt="">
                </div>
                <div class="item">
                  <img src="img/slider2.jpg" alt="">
                </div>
                  <div class="item">
                  <img src="img/slider3.jpg" alt="">
                </div>
              </div>
                <div class="bot-shad"></div>
            </div>
        <!-- -->
    </div>
    </div>
    </div>
    <div class="abs">
        <div class="middle nav-wrap">
            <div class="row-fluid">
                <div class="span12">
                    <div class="navbar" id="home-nav">
                        <div class="navbar-inner">
                            <?php include('menu.php'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
</section>