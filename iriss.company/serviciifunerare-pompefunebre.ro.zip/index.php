<?php include('head.php'); ?>

    <?php include('header.php'); ?>
        <section id="mini-sitemap">
            <section id="content-area" class="page gradient">
            <div class="container container-shadow">
                <div class="row-fluid content-container page">
                    <!-- pachete -->
                        <div class="g1">
                            
                            <div class="p p1">
                                <div class="col-1">
                                    <h1>Pachet Traditional</h1>
                                    <h2>Se achita cu talonul de pensie</h2>
                                    
                                    <img src="img/sicriu-pachet-traditional.png" alt="">
                                </div>
                                <div class="col-2">
                                    <ul class="left">
                                        <li>Sicriu Traditional Complet</li>
                                        <li>Imbracaminte saten</li>
                                        <li>Capac sicriu saten</li>
                                        <li>Orar mare si orar mic</li>
                                        <li>Perna - Vual</li>
                                        <li>Cruce scrisa</li>
                                        <li>Constatare deces</li>
                                        <li>Imbalsamare</li>
                                        <li>Spalat si imbracat</li>
                                        <li>Declararea decesului</li>
                                        <li>Certificat de deces</li>
                                        <li>Adeverinta inhumare</li>
                                        <li>Acte Sanepid: depunere capela</li>
                                    </ul>
                                    
                                    <ul class="right">
                                        <li>Transport funerar</li>
                                        <li>Cos coliva (2buc)</li>
                                        <li>Sticla vin + ulei</li>
                                        <li>Set pahare plastic (coliva)</li>
                                        <li>Colaci</li>
                                        <li>Cap, Prescura, Arhanghel</li>
                                        <li>6 pachete pentru pomana</li>
                                        <li>12 bucati batiste, banuti, lumanari</li>
                                        <li>20 dolii pus in piept</li>
                                        <li>Doliu de pus la usa</li>
                                        <li>4 prosoape mici</li>
                                        <li>2 prosoape mari</li>
                                        <li>Manipulare sicriu optional</li>
                                    </ul>
                                    
                                    <div class="clear"><!-- --></div>
                                </div>
                                
                                <div class="clear"><!-- --></div>
                                
                                <div class="i">Tel. 0760.444.700&#160;Urgente NON-STOP</div>
                                <div class="t">1.190 LEI</div>
                            </div>
                            
                            <div class="p p2">
                                <div class="col-1">
                                    <h1>Pachet Pensionari</h1>
                                    <h2>Se achita cu talonul de pensie</h2>
                                    
                                    <img src="" alt="">
                                </div>
                                <div class="col-2">
                                    <ul class="left">
                                        <li>Sicriu Traditional Complet</li>
                                        <li>Imbracaminte saten</li>
                                        <li>Capac sicriu saten</li>
                                        <li>Orar mare si orar mic</li>
                                        <li>Perna - Vual</li>
                                        <li>Cruce scrisa</li>
                                        <li>Constatare deces</li>
                                        <li>Imbalsamare</li>
                                        <li>Spalat si imbracat</li>
                                        <li>Declararea decesului</li>
                                        <li>Certificat de deces</li>
                                        <li>Adeverinta inhumare</li>
                                        <li>Acte Sanepid: depunere capela</li>
                                    </ul>
                                    
                                    <ul class="right">
                                        <li>Transport funerar</li>
                                        <li>Cos coliva (2buc)</li>
                                        <li>Sticla vin + ulei</li>
                                        <li>Set pahare plastic (coliva)</li>
                                        <li>Colaci</li>
                                        <li>Cap, Prescura, Arhanghel</li>
                                        <li>6 pachete pentru pomana</li>
                                        <li>12 bucati batiste, banuti, lumanari</li>
                                        <li>20 dolii pus in piept</li>
                                        <li>Doliu de pus la usa</li>
                                        <li>4 prosoape mici</li>
                                        <li>2 prosoape mari</li>
                                        <li>Manipulare sicriu optional</li>
                                    </ul>
                                    
                                    <div class="clear"><!-- --></div>
                                </div>
                                
                                <div class="clear"><!-- --></div>
                                
                                <div class="i">Tel. 0760.444.700  Urgente NON-STOP</div>
                                <div class="t">1.190 LEI</div>
                            </div>
                            
                        </div>
                    <!-- end pachete -->
                </div>
            </div>
        </section>
        </section>

    <section id="content-area-home" class="page gradient home" style="margin: 0px;">
        <div class="container content-container">
            <div class="row-fluid container-shadow">
                <div class="span12 obits">
                <a class="send-flowers" href="#" title="Opens in a new window" target="_blank">Send Flowers</a>
                <div class="row-fluid">
                <div class="span6 offset1">
                <h2><a href="servicii-funerare.php">Vezi <br> &nbsp; Tot</a> </h2>
                </div>
                </div>
                    <div class="row-fluid obit-list">
                    <div class="span4">
                        <div class="row-fluid">
                            <div class="span4 offset1">
                                <a href="#">
                                    <img src="img/contact.png" alt="" class="obit-pic">
                                </a>
                            </div>
                            <div class="span6 obit-info">
                                <span class="name">CONTACT NON-STOP</span>
                                <span class="dates">In 30 minute suntem la dumneavoastra.</span>
                                <span class="service">
                                <strong>Telefon:</strong><br>
                                0724.112.655</span>
                            </div>
                        </div>
                    </div>
                    <div class="span4">
                        <div class="row-fluid">
                            <div class="span4 offset1">
                                <a href="#">
                                    <img src="img/transport.png" alt="" class="obit-pic">
                                </a>
                            </div>
                            <div class="span6 obit-info">
                                <span class="name">TRANSPORT FUNERAR</span>
                                <span class="dates">Oferim Transport Funerar NON-STOP intern, extern si Zona Cargo</span>
                            </div>
                        </div>
                    </div>
                    <div class="span4">
                        <div class="row-fluid">
<!--
                            <div class="span4 offset1">
                                <a href="#">
                                    <img src="img/harta_sectoare_bucuresti.png" alt="" class="obit-pic">
                                </a>
                            </div>
-->
                            <div class="span12 obit-info frr">
                                <span class="name name2"><i>A</i>coperim urmatoarele sectoare:</span>
                                <span class="name">Sector 1 - Ion Mihalache</span>
                                <span class="name">Sector 2 - Sos. Colentina</span>
                                <span class="name">Sector 3 - Teodor Pallady</span>
                                <span class="name">Sector 4 - Brancoveanu</span>
                                <span class="name">Sector 5 - Rahova</span>
                                <span class="name">Sector 6 - Drumul Taberei</span>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</section>

<!-- -->

<?php include('footer.php'); ?>