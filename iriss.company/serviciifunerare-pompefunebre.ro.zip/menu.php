<ul class="nav">
    <li id="menu-item-857" class="menu-item menu-item-type-post_type menu-item-object-page dropdown menu-item-857">
        <a href="/" class="dropdown-toggle" data-toggle="">Acasa</a>
    </li>
    <li id="menu-item-891" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-891">
        <a href="servicii-funerare.php">Servicii Funerare</a></li>
        <li id="menu-item-1867" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1867">
            <a href="transport-funerar.php">Transport funerar</a></li>
        <li id="menu-item-1418" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1418">
            <a href="contact.php">Contact</a></li>
    <li class="mare"><a href="tel://+40724112655">Tel: &nbsp;&nbsp;&nbsp;&nbsp;0724.112.655</a></li>
</ul>