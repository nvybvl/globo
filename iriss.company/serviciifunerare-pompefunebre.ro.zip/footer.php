            <section id="footer">
                <div class="row-fluid container">

                <div class="middle nav-wrap">
                <div class="row-fluid">
                <div class="span12">
                <div class="navbar" id="home-nav">
                <div class="navbar-inner-foot">
                <?php include ('menu.php'); ?>
                </div>
                </div>
                </div>
                </div>
                </div>

                <div class="span12">
                    <div class="row-fluid">
                        <div class="span4 left">
                            <span class="title">"Un pas" dificil tratat cu discretie si bun simt...</span>
                        </div>
                        <div class="span4 center">
                        </div>
                        <div class="span4 right">
                            <div class="adr">
                                <div class="tel">
                                    <a href="tel://0040724112655">0724.112.655</a>
                                </div>
                                <div class="street-address">
                                    <div class="address_row">
                                        <span class="address1">Indiferent de ora sau sector </span>
                                    </div>
                                    <div class="address_row">
                                        <span class="city">Bucuresti NON-STOP</span>
                                       
                                    </div> 
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                </div>
            </section> 

        </div>
    </body>
</html>